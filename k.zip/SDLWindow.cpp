#include <iostream>
#include "SDLWindow.h"

SDLWindow::~SDLWindow()
{
    if (window != nullptr)
    {
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);

        SDL_Quit();
    }
}

bool SDLWindow::init()
{
    window = SDL_CreateWindow("SDL Window",
                              SDL_WINDOWPOS_UNDEFINED,
                              SDL_WINDOWPOS_UNDEFINED,
                              width, height, 0);
    if (window == nullptr)
        return false;

    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (renderer == nullptr)
    {
        SDL_DestroyWindow(window);
        SDL_Quit();
        return false;
    }
    
    return true;
}

void SDLWindow::drawBMP(const std::vector<std::vector<uint8_t>>& bmp_data,size_t width){
    unsigned y=0;
    auto it= bmp_data.rbegin();
    while(it!=bmp_data.rend())
   {    const auto& row= *it;
        unsigned x=0;
        unsigned pos=0;
        while(x<width){
            
            uint8_t blue= row[pos++];
            uint8_t green= row[pos++];
            uint8_t red = row[pos++];
             SDL_SetRenderDrawColor(renderer,red,green,blue,255);
             SDL_RenderDrawPoint(renderer,x,y);
            x++;

        }
        y++;
        it++;
    }
}

void SDLWindow::drawBMP2(const std::vector<std::vector<uint8_t>>& bmp_data,const std::vector<uint32_t>& colors, size_t width){
   
    unsigned y=0;
    auto it= bmp_data.rbegin();
   
    while(it!=bmp_data.rend())
   {    const auto& row= *it;
        unsigned x=0;
        unsigned pos=0;
        while(x<width){
           
           uint8_t p1=row[pos]<<4;
           p1=p1>>4;  
           uint32_t indice2= p1;
           uint32_t indice1= row[pos]>>4;
            uint32_t color1= colors.at(indice1);
            uint32_t color2= colors.at(indice2);
            uint32_t blue1= color1<<24;
            blue1=blue1>>24;
            uint32_t green1= color1<<16;
            green1= green1>>24;
            uint32_t red1=color1<<8;
            red1=red1>>24;
         
            uint32_t blue2= color2<<24;
            blue2=blue2>>24;
            uint32_t green2= color2<<16;
            green2= green2>>24;
            uint32_t red2=color2<<8;
            red2=red2>>24;
             SDL_SetRenderDrawColor(renderer,red1,green1,blue1,255);
             SDL_RenderDrawPoint(renderer,x,y);
             x++;
             
             SDL_SetRenderDrawColor(renderer,red2,green2,blue2,255);
             SDL_RenderDrawPoint(renderer,x,y);
             
             pos++;
             x++;
            
             

        }
        y++;
        it++;
    }
     
}
void SDLWindow::show(const std::vector<std::vector<uint8_t>>& bmp_data ,size_t width)
{
    SDL_ShowWindow(window);

    SDL_Event event;
    bool running = true;
    
    while (running)
    {
        SDL_WaitEvent(&event);

        switch (event.type)
        {
            case SDL_QUIT:
                running = false;
                break;
            case SDL_WINDOWEVENT:
                if (event.window.event == SDL_WINDOWEVENT_EXPOSED)
                {
                    SDL_SetRenderDrawColor(renderer,back_color.r, back_color.g,back_color.b,back_color.a);
                    SDL_RenderClear(renderer);
                    drawBMP(bmp_data,width);
                    
                    SDL_RenderPresent(renderer);
                }
                break;
        }
    }
}

void SDLWindow::show2(const std::vector<std::vector<uint8_t>>& bmp_data, const std::vector<uint32_t>& colors,size_t width)
{
    SDL_ShowWindow(window);

    SDL_Event event;
    bool running = true;
    
    while (running)
    {
        SDL_WaitEvent(&event);

        switch (event.type)
        {
            case SDL_QUIT:
                running = false;
                break;
            case SDL_WINDOWEVENT:
                if (event.window.event == SDL_WINDOWEVENT_EXPOSED)
                {
                    SDL_SetRenderDrawColor(renderer,back_color.r, back_color.g,back_color.b,back_color.a);
                    SDL_RenderClear(renderer);
                    drawBMP2(bmp_data,colors,width);
                    
                    SDL_RenderPresent(renderer);
                }
                break;
        }
    }
}