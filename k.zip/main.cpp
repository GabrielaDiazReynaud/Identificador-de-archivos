#include <iostream>
#include <fstream>
#include <vector>
#include "SDLWindow.h"
struct readBMP1{
char id[2];
uint32_t size;
uint16_t res1;
uint16_t res2;
uint32_t offset;


}__attribute__((packed));
struct readBMP2{

uint32_t sizeheader;
int32_t width;
int32_t height;
uint16_t colorplane;
uint16_t bpp;
uint32_t compression;
uint32_t imageSize;
uint32_t hResolution;
uint32_t vResolution;
uint32_t numberColors;
uint32_t importntCOlors;



}__attribute__((packed));
int main(int argc, char *argv[])
{
    std::ifstream in(argv[1]);
    readBMP1 lectura;
    readBMP2 lectura2;
   if(!in.is_open()){
       std::cout<<"ERROR";
       return -1;
   }
   
       in.read(reinterpret_cast<char*>(&lectura),sizeof(readBMP1));
       if(in.gcount()==sizeof(readBMP1)){
       std::cout<<"TYPE="<<lectura.id[0]<<lectura.id[1]<<std::endl;
       std::cout<<"SIZE="<<lectura.size<<std::endl;
       std::cout<<"RESERVED1="<<lectura.res1<<std::endl;
       std::cout<<"RESERVED2="<<lectura.res2<<std::endl;
       std::cout<<"OFFSET="<<lectura.offset<<std::endl;

       in.read(reinterpret_cast<char*>(&lectura2),sizeof(readBMP2));
       std::cout<<"HEADER SIZE="<<lectura2.sizeheader<<std::endl;
       std::cout<<"WIDTH="<<lectura2.width<<std::endl;
       std::cout<<"HEIGHT="<<lectura2.height<<std::endl;
       std::cout<<"COLOR PLANE="<<lectura2.colorplane<<std::endl;
       std::cout<<"BPP="<<lectura2.bpp<<std::endl;
       std::cout<<"COMPRESSION METHOD="<<lectura2.compression<<std::endl;
       std::cout<<"IMAGE SIZE="<<lectura2.imageSize<<std::endl;
       std::cout<<"HORIZONTAL RESOLUTION="<<lectura2.hResolution<<std::endl;
       std::cout<<"VERTICAL RESOLUTION="<<lectura2.vResolution<<std::endl;
       std::cout<<"NUMBER OF COLORS="<<lectura2.numberColors<<std::endl;
       std::cout<<"IMPORTANT COLORS="<<lectura2.importntCOlors<<std::endl;
       if(lectura2.numberColors>0){
          
           unsigned pofs=sizeof(readBMP1)+ lectura2.sizeheader;
           in.seekg(pofs);
           
           std::vector<uint32_t>pal(lectura2.numberColors);
           in.read(reinterpret_cast<char*>(pal.data()), pal.size()*sizeof(uint32_t));
           size_t row_size= ((lectura2.bpp* lectura2.width +31)/32)*4;
           std::vector<std::vector<uint8_t>> img_row(lectura2.height);
           in.seekg(lectura.offset);
           for(int i=0; i<lectura2.height; i++){
            img_row[i].resize(row_size);
            in.read(reinterpret_cast<char*>(img_row[i].data()),row_size);
            if(in.gcount()!=row_size){
               std::cerr <<"ERROR READING BMP";
               return 2;
            }
       }
       
         in.close();
        SDLWindow wnd(lectura2.width, lectura2.height);

        if (!wnd.init())
         {
          std::cerr << "Cannot create window: " << SDL_GetError() << '\n';
          SDL_Quit();
          return 2;
         }
    
         wnd.show2(img_row,pal,lectura2.width);

         SDL_Quit();

         return 0;
       }

     else{
       size_t row_size= ((lectura2.bpp* lectura2.width +31)/32)*4;
       std::vector<std::vector<uint8_t>> img_row(lectura2.height);
       in.seekg(lectura.offset);
       for(int i=0; i<lectura2.height; i++){
           img_row[i].resize(row_size);
           in.read(reinterpret_cast<char*>(img_row[i].data()),row_size);
           if(in.gcount()!=row_size){
               std::cerr <<"ERROR READING BMP";
               return 2;
           }
       }
       
    in.close();
    SDLWindow wnd(lectura2.width, lectura2.height);

    if (!wnd.init())
    {
        std::cerr << "Cannot create window: " << SDL_GetError() << '\n';
        SDL_Quit();
        return 2;
    }
    
    wnd.show(img_row, lectura2.width);

    SDL_Quit();

    return 0;
       }
}
}
